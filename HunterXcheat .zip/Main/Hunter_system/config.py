"""
⚙️ Hunter Proxy - Configuration
"""
import os

_BASE_DIR = os.path.dirname(os.path.abspath(__file__))
_DATA_DIR = os.path.join(_BASE_DIR, "data")

TOKENS = {
    "owner": "8945612535:AAFPtILYKdn-4taQGA6CPYV6gDNXUiw9WNE",
    "admin": "8835486612:AAFylOG9FXBs3IfskdNrtEpu6giEdNQQy2g",
    "user": "8932452435:AAHolgvsSG3DDmf0XqA-oQjUcl0ku-qHlsA"
}

OWNER_ID = 6548549598

PRICING = {
    "day": 0.1,
    "week": 0.3,
    "month": 0.8
}

DURATIONS = {
    "day": 1,
    "week": 7,
    "month": 30
}

DB_FILE = os.path.join(_DATA_DIR, "database.json")
IPS_FILE = os.path.join(_DATA_DIR, "allowed_ips.json")
KEYS_FILE = os.path.join(_DATA_DIR, "license_keys.json")

MAX_KEYS_PER_ADMIN = 10000
IP_API_URL = "https://api.ipify.org?format=json"
IP_LOOKUP_URL = "https://www.whatismyip.com/"
SUPPORT_USERNAME = "@M4TREXX"
MINI_APP_URL = "https://resellerdashbordffpanel.shop/miniapp"

SYSTEM_NAME = "Hunter Proxy"
