#!/bin/bash

# ═══════════════════════════════════════════════════════════════
# 🚀 Hunter Proxy - VPS Auto Installation Script
# ═══════════════════════════════════════════════════════════════

set -e

echo "═══════════════════════════════════════════════════════════════"
echo "🚀 Hunter Proxy - VPS Installation"
echo "═══════════════════════════════════════════════════════════════"
echo ""

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

PROJECT_DIR="/root/Hunter-proxy"
SERVER_IP="72.60.215.157" 

echo -e "${YELLOW}[1/8]${NC} Updating system..."
apt update && apt upgrade -y
echo -e "${GREEN}✅ System updated${NC}"
echo ""

echo -e "${YELLOW}[2/8]${NC} Installing dependencies..."
apt install -y python3 python3-pip git screen nano curl wget ufw htop
echo -e "${GREEN}✅ Dependencies installed${NC}"
echo ""

echo -e "${YELLOW}[3/8]${NC} Installing Python packages..."
cd $PROJECT_DIR
pip3 install -r requirements.txt
pip3 install mitmproxy
echo -e "${GREEN}✅ Python packages installed${NC}"
echo ""

echo -e "${YELLOW}[4/8]${NC} Configuring firewall..."
ufw --force enable
ufw allow 22/tcp
ufw allow 5000/tcp
ufw allow 9999/tcp
echo -e "${GREEN}✅ Firewall configured${NC}"
echo ""

echo -e "${YELLOW}[5/8]${NC} Updating IP addresses..."

sed -i "s|SERVER_URL = \"http://127.0.0.1:5000\"|SERVER_URL = \"http://72.60.215.157:5000\"|g" $PROJECT_DIR/proxy.py

sed -i "s|app.run(host='127.0.0.1', port=5000)|app.run(host='0.0.0.0', port=5000)|g" $PROJECT_DIR/Hunter_system/auth_server.py

echo -e "${GREEN}✅ IP addresses updated${NC}"
echo ""

echo -e "${YELLOW}[6/8]${NC} Creating systemd services..."

cat > /etc/systemd/system/Hunter-auth.service << EOF
[Unit]
Description=Nitro Proxy Auth Server
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=$PROJECT_DIR/Hunter_system
ExecStart=/usr/bin/python3 $PROJECT_DIR/Hunter_system/auth_server.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

cat > /etc/systemd/system/Hunter-bots.service << EOF
[Unit]
Description=Nitro Proxy Telegram Bots
After=network.target Hunter-auth.service

[Service]
Type=simple
User=root
WorkingDirectory=$PROJECT_DIR/Hunter_system
ExecStart=/usr/bin/python3 $PROJECT_DIR/Hunter_system/bots.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

# Proxy Server Service (mitmdump)
# مهم: block_global=false يسمح للموبايل بالاتصال من الإنترنت. بدونها mitmproxy يقتل الاتصال (killed by block_global).
# Important: block_global=false allows remote clients. Default true blocks public IPs connecting to this VPS.
cat > /etc/systemd/system/Hunter-proxy.service << EOF
[Unit]
Description=Nitro Proxy Server (mitmdump, block_global off for remote users)
After=network.target Hunter-auth.service

[Service]
Type=simple
User=root
WorkingDirectory=$PROJECT_DIR
ExecStart=/usr/local/bin/mitmdump -s $PROJECT_DIR/proxy.py --listen-host 0.0.0.0 --listen-port 9999 --set block_global=false
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

echo -e "${GREEN}✅ Systemd services created${NC}"
echo ""

echo -e "${YELLOW}[7/8]${NC} Starting services..."
systemctl daemon-reload
systemctl enable Hunter-auth Hunter-bots Hunter-proxy
systemctl start Hunter-auth
sleep 3
systemctl start Hunter-bots
sleep 2
systemctl start Hunter-proxy
echo -e "${GREEN}✅ Services started${NC}"
echo ""

echo -e "${YELLOW}[8/8]${NC} Installing security tools..."
apt install -y fail2ban
systemctl enable fail2ban
systemctl start fail2ban
echo -e "${GREEN}✅ Security tools installed${NC}"
echo ""


echo "═══════════════════════════════════════════════════════════════"
echo "📊 Services Status"
echo "═══════════════════════════════════════════════════════════════"
echo ""

systemctl status Hunter-auth --no-pager -l | head -n 5
echo ""
systemctl status Hunter-bots --no-pager -l | head -n 5
echo ""
systemctl status Hunter-proxy --no-pager -l | head -n 5
echo ""

echo "═══════════════════════════════════════════════════════════════"
echo "✅ Installation Complete!"
echo "═══════════════════════════════════════════════════════════════"
echo ""
echo "🌐 Server IP: 72.60.215.157"
echo "🔒 Auth Server: http://72.60.215.157:5000"
echo "🔌 Proxy Server: http://72.60.215.157:9999"
echo ""
echo "📋 Useful Commands:"
echo "  - Check status: systemctl status Hunter-bots"
echo "  - View logs: journalctl -u Hunter-bots -f"
echo "  - Restart: systemctl restart Hunter-bots"
echo "  - Stop: systemctl stop Hunter-bots"
echo ""
echo "═══════════════════════════════════════════════════════════════"
